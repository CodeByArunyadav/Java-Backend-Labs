package com.hoxcloud.lab.service;

import com.hoxcloud.lab.entity.UserEntity;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

@Service
@RequiredArgsConstructor
public class JwtService {
    @Value("${jwt.secret}")
    private String secretKey;
    @Value("${jwt.refreshToken}")
    private String refreshTokenKey;
    @Value("${jwt.expiration}")
    private Long expiration;
    @Value("${jwt.refreshTokenExpire}")
    private  Long refreshTokenExpire;

    private SecretKey getSecretKey() {
        return Keys.hmacShaKeyFor(secretKey.getBytes(StandardCharsets.UTF_8));
    }

    private SecretKey getRefreshSecretKey(){return Keys.hmacShaKeyFor(refreshTokenKey.getBytes(StandardCharsets.UTF_8));}

    public String generateToken(UserEntity user) {
        return Jwts.builder()
                //.subject(String.valueOf(user.getId()))
                .subject(user.getEmail())
                .claim("roles",user.getRoles().toString())
                .claim("type","ACCESS")
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + expiration))
                .signWith(getSecretKey())
                .compact();
    }

    public String refreshToken(UserEntity user) {
        return Jwts.builder()
                //.subject(String.valueOf(user.getId()))
                .subject(user.getEmail())
                .claim("type","REFRESH")
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + refreshTokenExpire))
                .signWith(getRefreshSecretKey())
                .compact();
    }
    public Claims extractRefreshClaim(String refreshToken)
    {
        return Jwts.parser()
                .verifyWith(getRefreshSecretKey())
                .build()
                .parseSignedClaims(refreshToken)
                .getPayload();
    }

    public String extractRfreshUserName(String token) {
        return extractRefreshClaim(token).getSubject();
    }

    public boolean validateToken(String token, UserDetails userDetails) {

        String tokenUsername = extractUserName(token);
        String dbUsername = userDetails.getUsername();
        String tokenType = extractTokenType(token);
        boolean expired = isTokenExpired(token);

       /* System.out.println("Token Username : " + tokenUsername);
        System.out.println("DB Username    : " + dbUsername);
        System.out.println("Username Match : " + tokenUsername.equals(dbUsername));

        System.out.println("Token Type     : " + tokenType);
        System.out.println("Type Match     : " + "ACCESS".equals(tokenType));

        System.out.println("Expired        : " + expired);*/

        return tokenUsername.equals(dbUsername)
                && "ACCESS".equals(tokenType)
                && !expired;
    }


    public Claims extrectAllClaims(String token) {
        return Jwts.parser()
                .verifyWith(getSecretKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    public String extractUserName(String token) {
        return extrectAllClaims(token).getSubject();
    }

    public String extractUserId(String token)
    {
       return extrectAllClaims(token).getId();
    }

    public String extractTokenType(String token)
    {
        return extrectAllClaims(token).get("type",String.class);
    }


    private boolean isTokenExpired(String token) {

        return extrectAllClaims(token).getExpiration().before(new Date());
    }

    public String extractRole(String token) {
        return extrectAllClaims(token).get("role",String.class);
    }


}
